﻿
<?PHP

$name = $_POST['nombre'];
$tel = $_POST['numero'];
$correo = "noaplica";
$tcell = "noaplica";
$tplan = "noaplica";
$toperador ="crosselling";

require_once('lib/nusoap.php');

//$servicio="http://181.49.168.203:8084/Service.asmx";//url
$servicio="http://181.49.168.203:8084/Service.asmx?WSDL";//url

$parametros=array(); //parametros de la llamada
$parametros['campanaCliente']=7;//Siempre debe de ir este numero
$parametros['nombreCliente']=utf8_decode($name);
$parametros['telefonoCliente']=$tel;
$parametros['codSeguridad']="487KMCHWASYT2TR";//Siempre debe de ir esta Cadena
$parametros['equipoCliente']=$tcell;
$parametros['planCliente']=utf8_decode($tplan);
$parametros['operadorCliente']=$toperador;


$client = new nusoap_client($servicio,'wsdl');

$err = $client->getError();
if ($err) {
echo '<h2>Constructor error</h2><pre>' . $err . '</pre>';
}

//$client->setUseCurl($servicio);
//$client->soap_defencoding = 'UTF-8';

$result = $client->call("tigoUneTellamamos", $parametros);
//$result = $client->tigoUneTellamamos($parametros);

//echo var_dump($result)."<hr>".$result['tigoUneTellamamosResult'];

?>



